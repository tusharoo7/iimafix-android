import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ServiceImagePage } from './service-image';

@NgModule({
  declarations: [
    //ServiceImagePage,
  ],
  imports: [
    IonicPageModule.forChild(ServiceImagePage),
  ],
})
export class ServiceImagePageModule {}
