import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController, Events } from 'ionic-angular';
import { ImagePicker } from '@ionic-native/image-picker';
import { Base64 } from '@ionic-native/base64';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { GlobalServiceProvider } from '../../providers/global-service/global-service';
import { Toast } from '@ionic-native/toast';
//import { DatePicker } from 'ionic2-date-picker';
import { DatePickerProvider } from 'ionic2-date-picker';
import { ViewController, ModalController } from 'ionic-angular';
import { DatePickerOption } from 'ionic2-date-picker';

import { HomePage } from '../home/home';
@IonicPage()
@Component({
  selector: 'page-job-details-submit',
  templateUrl: 'job-details-submit.html',
  //providers: [DatePicker]
})
export class JobDetailsSubmitPage {
  img: any;
  imgData: any = [];
  imgDataView: any = [];
  f_type: any;
  remark: any;
  jobStatus: any;
  myDate: any = 'Date';
  selectedDate: String = new Date().toISOString();
  myTime: any;
  descrpn: any;
  price: any;
  adjustedTime: any;
  today: any;
  dateFlag: any = 'false';
  cashrecived:any ;
  //modalCtrl:any;
  //viewController:any;
  constructor(public modalCtrl: ModalController, public viewCtrl: ViewController, private datePickerProvider: DatePickerProvider, public events: Events, private toast: Toast, public globalservice: GlobalServiceProvider, public navCtrl: NavController, public navParams: NavParams, private camera: Camera, private base64: Base64, private imagePicker: ImagePicker, public alertCtrl: AlertController) {
    // //this.myDate = new Date();
    // //  this.today.setDate(30).toISOString();
    // // alert(today);

    // this.datePicker = new DatePicker(<any>this.modalCtrl, <any>this.viewCtrl);
    // this.datePicker.onDateSelected.subscribe((date) => {
    //   this.dateFlag = 'true';
    //   let TempDate = new Date(date.getTime() + 24 * 60 * 60 * 1000).toISOString().substring(0, 10);
    //   let day=TempDate.split('-')[2];
    //   let month=TempDate.split('-')[1];
    //   let year=TempDate.split('-')[0];
    //  // alert(TempDate.split('-')[0]);
    //   //alert(this.myDate.split('-')[1]);
    //   //alert(this.myDate.split('-')[2]);
    //    this.myDate=day.concat('/').concat(month).concat('/').concat(year);
    //   //alert(day.split('-')[2].concat('/').concat(month.split('-')[1]).concat('/').concat(year.split('-')[0]));
    //   //alert(this.myDate.substring(0, 10));

    //   // alert(this.myDate.getDate());
    //   //alert(this.myDate.getFullYear);
    //   //alert(this.myDate.getMonth);
    //   //alert(date); 
    // });
   // this.cashrecived=0;
    this.jobStatus = sessionStorage.getItem('status');
    if (this.jobStatus != 'pending') {
      this.myDate = '';
      this.adjustedTime = '';
      this.descrpn = '';
      this.price = '';
    }
    else {
      this.price = '';
    }

  }
  // showCalendar() {
  //   let datePickerOption: DatePickerOption = {
  //     minimumDate: new Date() // the minimum date selectable
  //   };
  //   this.datePicker.showCalendar(datePickerOption);
  // }
   showCalendar() {
     let datePickerOption: DatePickerOption = {
      minimumDate: new Date() // the minimum date selectable
      //maximumDate: new Date() // the maximum date selectable
}; 
    let dateSelected = 
      this.datePickerProvider.showCalendar(this.modalCtrl,datePickerOption);
    dateSelected.subscribe(date => {
    // alert(date);
      this.dateFlag = 'true';
      let TempDate = new Date(date.getTime() + 24 * 60 * 60 * 1000).toISOString().substring(0, 10);
      let day=TempDate.split('-')[2];
      let month=TempDate.split('-')[1];
      let year=TempDate.split('-')[0];
      this.myDate=day.concat('/').concat(month).concat('/').concat(year);
    });
  }
  ionViewDidLoad() {
    //this.datePicker.showCalendar();
    console.log('ionViewDidLoad JobDetailsSubmitPage');
  }

  getImageSource() {

    let confirm = this.alertCtrl.create({
      title: 'Pick images from gallery or capture images using camera.',
      message: '',
      buttons: [
        {
          text: 'CAMERA',
          handler: () => {
            this.getCamera();
          }
        },
        {
          text: 'GALLERY',
          handler: () => {
            this.imgPicker();
          }
        }
      ]
    });
    confirm.present();
  }
  getCamera() {
    const options: CameraOptions = {
      quality: 30,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE,
      correctOrientation: true,
      targetWidth:800,
      targetHeight:800
    }
    this.camera.getPicture(options).then((imageData) => {
      if (this.imgData.length < 5) {
        let base64Image = 'data:image/jpeg;base64,' + imageData;
        this.img = base64Image;
        this.imgDataView.push({ "img": this.img });
        //sessionStorage.setItem('profImage', base64Image.split(',')[1]);
        //sessionStorage.setItem('profImage_type', 'jpg');
        this.imgData.push({ "img": encodeURIComponent(base64Image.split(',')[1]), "fileType": 'jpg' });
      }
      else {
        let alert = this.alertCtrl.create({
          title: 'Oops! You cannot select more than 5 images.',
          message: '',
          buttons: [
            {
              text: 'Ok',
            }
          ]
        });
        alert.present();
      }
    }, (err) => {
      // Handle error
    });

  }
  imgPicker() {
    let options = {
      maximumImagesCount: 5 - this.imgData.length, // Android only since plugin version 2.1.1, default no limit
      quality: 30, // 0-100, default 100 which is highest quality
      width: 800,  // proportionally rescale image to this width, default no rescale
      height: 800, // same for height
    }
    this.imagePicker.getPictures(options).then((results) => {
      if (this.imgData.length < 5) {
        for (var i = 0; i < results.length; i++) {
          // alert('Image URI: ' + results[i]);
          if( results[i].substr(results[i].lastIndexOf('.') + 1)=='gif'){
          
             let alert = this.alertCtrl.create({
            title: 'iimafix',
            subTitle: '<strong>Image not supported, please choose another image.</strong>',
            buttons: [
              {
                text: 'OK',
                handler: data => {
                  this.getImageSource();
                }
              }
            ]
          });
          alert.present();
            break;
          }
          else{
             this.img = results[i];
          this.imgDataView.push({ "img": this.img });
          sessionStorage.setItem('profImage_type', results[i].substr(results[i].lastIndexOf('.') + 1));
          this.f_type = results[i].substr(results[i].lastIndexOf('.') + 1);
          this.fileToBase64(results[i]);
          }
         
        }
      }
      else {
        let alert = this.alertCtrl.create({
          title: 'Oops!You can not select more then 5 images.',
          message: '',
          buttons: [
            {
              text: 'Ok',
            }
          ]
        });
        alert.present();
      }
    }, (err) => { });
  }
  fileToBase64(path) {
    //alert('o');
    let filePath: any = path;
    this.base64.encodeFile(filePath).then((base64File: any) => {
      //sessionStorage.setItem('profImage', base64File.split(',')[1]);
      console.log(base64File);
      this.imgData.push({ "img": encodeURIComponent(base64File.split(',')[1]), "fileType": this.f_type });
      console.log(this.imgData);
    }, (err) => {
      console.log(err);
    });
  }
  tConvert(time) {
    // Check correct time format and split into components
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

    if (time.length > 1) { // If time format correct
      time = time.slice(1);  // Remove full string match value
      time[5] = +time[0] < 12 ? ' AM' : ' PM'; // Set AM/PM
      time[0] = +time[0] % 12 || 12; // Adjust hours

    }
    this.adjustedTime = time.join('');
    //alert(time.join(''));
    //return time.join (''); // return adjusted time or original string

  }
  serviceDetailsSubmit() {
    //alert(this.myDate);
    //alert(this.myTime);
    console.log(this.cashrecived);
    if (this.myTime) {
      this.tConvert(this.myTime);
    }
    // alert('pp');
    if (this.imgData.length < 1) {
      this.toast.show('Please upload atleast one image', '2000', 'bottom').subscribe(
        toast => {
          console.log(toast);
        })
    }
    else if (this.jobStatus == 'pending' && this.myDate == 'Date' || this.jobStatus == 'pending' && this.myDate == '' || this.jobStatus == 'pending' && this.myDate == undefined) {
      this.toast.show('Please select job date', '2000', 'bottom').subscribe(
        toast => {
          console.log(toast);
        })
    }
    else if (this.jobStatus == 'pending' && this.adjustedTime == '' || this.jobStatus == 'pending' && this.adjustedTime == undefined) {
      this.toast.show('Please select job time', '2000', 'bottom').subscribe(
        toast => {
          console.log(toast);
        })
    }
    else if (this.jobStatus == 'pending' && this.descrpn == '' || this.jobStatus == 'pending' && this.descrpn == undefined) {
      this.toast.show('Job description should not be blank', '2000', 'bottom').subscribe(
        toast => {
          console.log(toast);
        })
    }
    
    else if(this.cashrecived!=undefined &&  this.cashrecived!="" && !new RegExp("^[0-9]+(\.[0-9]{1,2})?$").test(this.cashrecived))
    {
      console.log(this.cashrecived);
      this.toast.show('Please enter valid amount', '2000', 'bottom').subscribe(
        toast => {
          console.log(toast);
        })
    }
    else {
      if(this.cashrecived==undefined || this.cashrecived=="" )
      {
        this.cashrecived=0;
      }
      let loadingPop = this.globalservice.createLoadingBar();
      loadingPop.present();
      this.globalservice
        .jobDetailsSubmit(this.globalservice.serviceUrl + 'service-report-submit', this.globalservice.deviceOs,
        this.globalservice.deviceOsVer,
        this.globalservice.appVertion,
        localStorage.getItem('memberId'),
        localStorage.getItem('sessionId'),
        sessionStorage.getItem('rqstId'),
        JSON.stringify(this.imgData),
        //'testing',
        this.remark,
        this.cashrecived,
        this.jobStatus,
        this.myDate,
        this.adjustedTime,
        this.descrpn,
        this.price
        )
        .subscribe(
        data => {
          console.log(JSON.stringify(data));
          loadingPop.dismiss();
          if (data.responseStatus.STATUS == 'SUCCESS') {
            console.log("test root");
            this.toast.show(data.responseStatus.MESSAGE, '2000', 'bottom').subscribe(
              toast => {
                console.log("test root home");
                this.navCtrl.popToRoot();
                // this.events.publish('details:updated', 'true');
              //  this.navCtrl.setRoot(HomePage);
              });
          }
          else {
            loadingPop.dismiss();
            this.toast.show(data.responseStatus.MESSAGE, '2000', 'bottom').subscribe(
              toast => {
                console.log(toast);
              });
          }
        },
        error => {
          loadingPop.dismiss();
          this.globalservice.errorMessage = <any>error
        });
    }
  }
  removeImg(index) {
    // alert(index);
    // alert(this.imgDataView.length);
    //  alert(this.imgData.length);
    this.imgDataView.splice(index, 1);
    this.imgData.splice(index, 1);
  }
}
