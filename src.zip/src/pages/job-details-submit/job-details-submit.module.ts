import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { JobDetailsSubmitPage } from './job-details-submit';

@NgModule({
  declarations: [
    //JobDetailsSubmitPage,
  ],
  imports: [
    IonicPageModule.forChild(JobDetailsSubmitPage),
  ],
})
export class JobDetailsSubmitPageModule {}
