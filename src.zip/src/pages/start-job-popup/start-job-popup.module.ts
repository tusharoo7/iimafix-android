import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { StartJobPopupPage } from './start-job-popup';

@NgModule({
  declarations: [
    //StartJobPopupPage,
  ],
  imports: [
    IonicPageModule.forChild(StartJobPopupPage),
  ],
})
export class StartJobPopupPageModule {}
